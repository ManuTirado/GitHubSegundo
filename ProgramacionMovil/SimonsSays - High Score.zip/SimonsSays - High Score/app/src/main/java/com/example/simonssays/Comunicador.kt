package com.example.simonssays

interface Comunicador {
    fun onClickVerde()
    fun onClickRojo()
    fun onClickAmarillo()
    fun onClickAzul()
}